#ifndef MAIN_H
#define MAIN_H

#include <GL/glut.h>
#include <iostream>
#include <vector>
#include <cmath>

#define count_vertex 800
#define win_size 700
#define point_size 9
#define interaction 1

#endif
