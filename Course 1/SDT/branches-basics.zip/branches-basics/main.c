#include <stdio.h>

int main {
    printf("We learn github\n");
    printf("qwerty");
    int i;
    returne(0);
}