#include "../libmatches/matches.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    int matches_heap, num = -1, player;
    char input[10];

point_start:
    matches_heap = initialcount;
    num = -1;
    system("clear");
    printf("Выберите, кто сделает первый ход с - компьютер, p - вы, r - "
           "случайно: ");
    scanf("%s", input);
    player = first_player(input);

    for (int i = 0; i < 100; i++) {
        system("clear");
        if (num != -1) {
            printf("Я взял %d шт.\n", num);
        }
        //ход игрока
        if (player == 2) {
            printf("Ваш ход. В куче %d спичек.\n", matches_heap);
            printf("Сколько штук вы хотите взять? ('q' - для выхода, 'n' - для "
                   "перезапуска)\n");
        point_move:
            scanf("%s", input);
            num = player_move(input);
            if (num == -1) {
                player = 3;
                break;
            } else if (num == -5) {
                goto point_start;
            }
            num = move_check(num, matches_heap);
            if (num == -3) {
                goto point_move;
            }
            matches_heap -= num;
            if (matches_heap <= 0) {
                break;
            }
        }

        player = 1;
        num = coputer_move(matches_heap);
        matches_heap -= num;
        if (matches_heap <= 0) {
            break;
        }
        player = 2;
    }
    system("clear");
    if (player == 2) {
        printf("Поздравляю! Вы победили!\n");
    } else if (player == 1) {
        printf("Я взял %d шт.\n", num);
        printf("В куче 0 спичек.\n");
        printf("Вы проиграли!\n");
    } else {
        printf("Жаль! Приходите, когда захотите сыграть ещё.\n");
    }

    return 0;
}