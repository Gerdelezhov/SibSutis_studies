#pragma once

const int initialcount = 100;

int first_player(char input[10]);
int move_check(int num, int matches_heap);
int player_move(char input[10]);
int coputer_move(int matches_heap);